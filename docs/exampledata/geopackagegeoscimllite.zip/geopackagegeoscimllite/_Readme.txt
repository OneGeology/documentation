OneGeology example data

GeologicUnitView.gpkg - GeoPackage file with harmonised bedrock geology map data using field names from GeoSciML-Lite GeologicUnitView feature type and field values from appropriate INSPIRE vocabularies.
ShearDisplacementStructureView.gpkg - GeoPackage file with harmonised fault map data using field names from GeoSciML-Lite ShearDisplacementStructure feature type and field values from appropriate INSPIRE vocabularies.
