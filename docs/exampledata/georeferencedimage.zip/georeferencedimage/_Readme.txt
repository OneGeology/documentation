OneGeology example data

bedrock625ll.png - An image of a geological map.
bedrock625ll.wld - ESRI format world file which locates image geographically on an EPSG:4326 (WGS 84 lat lon) projection map.
bedrockAgeLegend.png - Image of map legend.