OneGeology example data

bedrock625ll.[dbf,prj,sbn,sbx,shp,shp.xml,shx] - ESRI Shapefile with bedrock geology data using provider (BGS) specific fields.
bedrock625ll.avl - ESRI ArcView GIS legend file for above Shapefile.